package com.example.mainmenu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class activity_about_us5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us5);

        Button btnBackToMenu = findViewById(R.id.btn_Back_to_Menu);

        btnBackToMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to activity_about_us4
                startActivity(new Intent(activity_about_us5.this, activity_about_us4.class));
                finish(); // Close this activity
            }
        });
    }
}
