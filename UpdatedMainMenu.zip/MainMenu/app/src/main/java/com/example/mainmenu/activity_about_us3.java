package com.example.mainmenu;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import androidx.appcompat.app.AppCompatActivity;

public class activity_about_us3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us3);

        Button btnBackToMenu = findViewById(R.id.btn_Back_to_Menu);
        Button btnNextPage = findViewById(R.id.btn_Next_Page);

        btnBackToMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back page
                startActivity(new Intent(activity_about_us3.this, activity_about_us2.class));
                finish(); // Close this activity
            }
        });

        btnNextPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the next page (ActivityAboutUs2)
                startActivity(new Intent(activity_about_us3.this, activity_about_us4.class));
            }
        });
    }
}
