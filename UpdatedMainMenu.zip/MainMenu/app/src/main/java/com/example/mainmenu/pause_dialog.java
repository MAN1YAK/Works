package com.example.mainmenu;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatDialog;

public class pause_dialog extends Dialog {
    private Button btnMute;
    private Button btnGoBackToMenu;
    private Button btnRestartRound;
    private Button btnClose;

    private boolean isMuted = false; // Track mute state
    private boolean isPaused = false;
    private DialogCallback callback;

    public pause_dialog(Context context, DialogCallback callback) {
        super(context);
        this.callback = callback;

        SharedPreferences prefs = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        isMuted = prefs.getBoolean("isMuted", false);
    }

    public pause_dialog(activity_start_game context) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_pause);

        // Initialize buttons
        btnMute = findViewById(R.id.btn_mute);
        btnGoBackToMenu = findViewById(R.id.btn_go_back_to_menu);
        btnRestartRound = findViewById(R.id.btn_restart_round);
        btnClose = findViewById(R.id.btn_close);

        // Set click listeners
        btnMute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMute(); // Toggle mute state
            }
        });

        btnGoBackToMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SoundPlayer.stopBGM();
                // Handle go back to menu button click
                // Implement the logic to navigate back to the MainActivity
                Intent intent = new Intent(getContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                getContext().startActivity(intent);
                dismiss(); // Dismiss the dialog after performing the action
            }
        });

        btnRestartRound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle restart round button click
                // Implement the logic to restart the current round or game
                // For example:
                // YourRestartRoundMethod(); // Call your method to restart the round
                dismiss(); // Dismiss the dialog after performing the action
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the dialog to continue the game
                sendBooleanToActivity(true, isMuted);
                dismiss();
            }
        });

        updateMuteButtonBackground(isMuted);
    }

    private void toggleMute() {
        isMuted = !isMuted; // Toggle mute state
        // Set mute state using settingManager
        SharedPreferences prefs = getContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("isMuted", isMuted);
        editor.apply();
        // Update button background based on new mute state
         updateMuteButtonBackground(isMuted);
    }
    private void updateMuteButtonBackground(boolean isMuted) {
        if (!isMuted) {
            btnMute.setBackgroundResource(R.drawable.soundoff);
        } else {
            btnMute.setBackgroundResource(R.drawable.soundon);
        }
    }

    public interface DialogCallback {
        void onBooleanPassed(boolean value, boolean value2);
    }

    private void sendBooleanToActivity(boolean value, boolean value2) {
        if (callback != null) {
            callback.onBooleanPassed(value, value2);
        }
    }
}
