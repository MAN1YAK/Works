package com.example.mainmenu;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.util.Log;

public class SoundPlayer {
    private static MediaPlayer player;
    private static SoundPool soundPool;
    private static int sfx1, sfx2, sfx3, sfx4, sfx5;
    private static int length;
    private static float volume = 1.0f;

    private static AudioAttributes aa = new AudioAttributes.Builder()
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .setUsage(AudioAttributes.USAGE_GAME)
            .build();

    public static void initialize(Context context) {
        if (soundPool == null) {
            soundPool = new SoundPool.Builder()
                    .setMaxStreams(10)
                    .setAudioAttributes(aa)
                    .build();
            sfx1 = soundPool.load(context, R.raw.buttonpress, 1);
        }
    }
    public static void playBGM(Context context){
            player = MediaPlayer.create(context, R.raw.runningbgm1);
            player.seekTo(length);
            player.start();
    }

    public static void pauseBGM(){
        if(player.isPlaying()){
            player.pause();
            length = player.getCurrentPosition();
        }
    }

    public static void stopBGM(){
        player.stop();
        length = 0;
    }

    public static void muteVolume(){
        volume = 0.0f;
        if (player != null) {
            player.setVolume(volume, volume);
        }
    }

    public static void unmuteVolume() {
        volume = 1.0f;
        if (player != null) {
            player.setVolume(volume, volume);
        }
    }

    public static void playSFX_ButtonClicked(Context context) {
        if (soundPool == null) {
            initialize(context);
        }
        soundPool.play(sfx1, 1, 1, 1, 0, 1);
    }



}

