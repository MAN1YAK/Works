package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int START_TIME_IN_MILLIS = 90000;
    private TextView scoreText, counterText, timeLeft;
    private int runningScore = 0;
    private int pickupScore = 0;
    private int totalScore = 0;
    CountDownTimer cTimer;
    private boolean mTimerRunning;
    private boolean mTimerFinished;
    private long mTimeLeftInMills = START_TIME_IN_MILLIS;
    private Button settings, addScore;
    private int lastSecondUpdated = -1;
    MediaPlayer player;
    private int cdi = 1000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        counterText = findViewById(R.id.countText);
        settings = findViewById(R.id.settings);
        addScore = findViewById(R.id.scoreAdd);
        scoreText = findViewById(R.id.scoreText);
        timeLeft = findViewById(R.id.timeLeft);

        // Update the count-down text UI element
        updateCountDownText();

        // Start playing background music
        play();

        //placeholder for starting the game
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // If timer is running, pause it. Otherwise, start the timer
                if(mTimerRunning){
                    pauseTimer();
                } else if (mTimerFinished) {
                    // irrelevant to code
                } else{
                    startTimer();
                }
             }
        });

        //placeholder of power ups picked
        addScore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickupScore += 50;
            }
        });

    }
    //start timer
    private void startTimer() {

        cTimer = new CountDownTimer(mTimeLeftInMills, cdi) {
            Handler mHandler = new Handler();

            public void onTick(long millisUntilFinished) {
                mTimeLeftInMills = millisUntilFinished;

                //if time left is 60 seconds change cdi to 100 millisecond
                if(mTimeLeftInMills <= 60000){
                    cdi = 100;
                    pauseTimer();
                    startTimer();
                }

                int currentSecond = (int) (millisUntilFinished / 100);
                if(currentSecond != lastSecondUpdated){
                    updateScore();
                    lastSecondUpdated = currentSecond;
                }

                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        timeLeft.setText(String.valueOf(mTimeLeftInMills));
                        updateCountDownText();
                    }
                });

            }
            //when timer finished
            public void onFinish() {
                mTimerFinished = true;
                mTimerRunning = false;
                Toast.makeText(getApplicationContext(), "Finished", Toast.LENGTH_SHORT).show();
            }
        }.start();

        mTimerRunning = true;
    }
    private void pauseTimer(){
        cTimer.cancel();
        mTimerRunning = false;
    }

    // Update the count-down textView
    private void updateCountDownText() {
        int seconds = (int) (mTimeLeftInMills / 1000);
        String timeleftFormatted = String.format(Locale.getDefault(), "%02d", seconds);
        counterText.setText(timeleftFormatted);
    }

    private void updateScore() {
        // Increment running score based on time left
        if (mTimeLeftInMills >= 30000) {
            //add 10 score every second
            runningScore += 1;
        } else {
            //makes sure that the incrementation of runningScore does not go over 1800, max incrementation of score is 100 second
            runningScore += Math.min(3330 - runningScore, 10);
        }
        // Calculate total score and format it, then set it to the score textView
        totalScore = runningScore + pickupScore;
        String formattedScore = String.format("%06d", totalScore);
        scoreText.setText(formattedScore);
    }

    // Start playing background music
    public void play(){
        if (player == null){
            player = MediaPlayer.create(this, R.raw.runningbgm);
        }
        player.start();
    }

    }
